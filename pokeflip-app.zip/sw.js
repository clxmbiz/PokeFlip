const C="pokeflip-v3",F=["./","index.html","manifest.json","icon-192.png","icon-512.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F))));
self.addEventListener("fetch",e=>{const u=new URL(e.request.url);if(u.origin!==location.origin)return;
if(u.pathname.endsWith("data.json")){e.respondWith(fetch(e.request).catch(()=>caches.match("data.json")));return}
e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
